#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
  int fd[2]; 
  int pid;
  int i,j,nbytes;

  char rdbuf[80]; 
  pipe(fd);
 
  if((pid=fork())== -1)
  {
    perror("Fork function");	
    exit(1);
   }
   if(pid==0)
   {
     close(fd[0]);
     for(i=0;i<5;i++)
       {
        char str[20]="";  
        for(j=0; j<=i; j++)
			strcat(str,"*");
			strcat(str,"\n");
			write(fd[1],str,strlen(str)+1);
        }
    }
    else
    {
         close(fd[1]);
          for(i=0;i<5;i++)
          {
             nbytes=read(fd[0],rdbuf,sizeof(rdbuf));
             printf("%s",rdbuf);
           }
    }
	return 0;
}
