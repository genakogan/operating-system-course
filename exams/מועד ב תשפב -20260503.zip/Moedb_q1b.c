#include<stdio.h>                                                                                                                                                        
#include<stdlib.h>                                                                                                                                                       
#include<unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

int main()
{
	// creates a new file having full read/write permissions
	int fd = open("myfile", O_RDWR|O_CREAT, 0666);
	write(fd, "haha\n", 5);
	close(fd);					
	fd = open("myfile", O_RDWR);		
	close(0);
	close(1);
	dup(fd);
	dup(fd);
	if (fork() == 0)
	{
		char s[100];
		dup(fd);
		scanf("%s", s);
		printf("hello\n");
		write(2, s, strlen(s));		
		return 0;				
	}
	wait(NULL);
	printf("Father finished\n");
	close(fd);
	return 0;
}
