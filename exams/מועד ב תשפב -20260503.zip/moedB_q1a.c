#include <stdio.h>
#include <unistd.h>

#define N 4

int main()
{
	int c1;
	int c2;
	int t;
	int i;

	c2 = 1;
	c1 = 0;

	for (i = 1; i < N; i++)
	{
		switch(fork())
		{
			case -1: 
				printf("Error creating process\n");
				return -1;
			case 0:
				t = c1 + c2;
				c1 = c2;
				c2 = t;
				break;
			default:
				i = N;
				break;
		}
	}

	wait(&t);
	printf("%d ",c2);
}
