#include <stdio.h>
#include <unistd.h>

#define READ  0
#define WRITE 1
#define N 5

int main()
{
	 	int p, i, j, level=0, result=1;
	 	int lc[2];
	 	char ch;

	 	pipe(lc);

	 	for(i = 0; i < N; i++)
	 	{
	       	switch(fork())
      	{
	 			case -1: 
	 				printf("Error creating process\n");
 				return -1;
	 			case 0:
	 				level++;
					break;
	 			default:
	 				i=N;
	 				break;
	 		   }
	 	}

	 	
	 	for(j=1; j <= N; j++)
	 	{
			if (level == j)
	 		{
	 			close(lc[READ]);
	 			ch = (char)level;
	 			write(lc[WRITE],&ch,1);
	 		}
	 	}
	
		
		if (level == 0)
		{
	 		close(lc[WRITE]);
	 		for( i = 0 ; read(lc[READ],&ch,1) != 0; i++)
			{
	 			result = result*(int)ch;
	 		}
	 		printf("result = %d\n",result);
	 	}
		
		return 0;
 }
