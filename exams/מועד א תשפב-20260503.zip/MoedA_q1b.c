#include <stdio.h>
#include <unistd.h>

int main(void)
{	
  int status;

  switch(fork())
  {
	case -1: 
	   printf("Error creating process\n");
	   return -1;
	case 0:
	   execlp("ls","ls",NULL,0);   
	   break;
	default:
	   wait(&status);
	   break;
   }
   printf("Process is finished");
   return 0;
}
