#include <stdio.h>
#include <signal.h>


void signalCatcher(){
	printf("%d does not want to die \n", getpid());
	//signal(SIGINT, signalCatcher);
}

int main(void){	
  int status;
 int pid1 = 0, pid2 = 0;
 int grade = 98;
 int me = getpid();

 signal(SIGINT, signalCatcher);

 pid1 = fork();
 if(getpid() != me){
	grade++;
      if( (pid2 = fork()) == 0)
       	grade++;
	pause();
 }else
   sleep(3);


 if( pid1 != 0){
	printf("%d wants to kill %d \n", getpid(), pid1);
	kill(pid1, SIGINT);
	wait(NULL);
 }

  if( pid2 != 0){
	printf("%d wants to kill %d \n", getpid(), pid2);
	kill(pid2, SIGINT);
	wait(NULL);
  }


  printf(" % d got % d and leaves \n", getpid(), grade);
  return;
}


